# hl7.fhir.no.smart#0.1.0: Smart

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [Blodprøve](StructureDefinition-mal-observation-blodprove.md)
* [Pasient](StructureDefinition-mal-patient.md)

### ImplementationGuides

* [Smart](index.md)

### Examples

* [Pasient-1 (Patient)](Patient-Pasient-1.md)
