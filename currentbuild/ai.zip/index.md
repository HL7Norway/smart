# Home - Smart v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/ig/smart/ImplementationGuide/hl7.fhir.no.smart | *Version*:0.1.0 |
| Draft as of 2026-10-08 | *Computable Name*:smart |

### SMART on FHIR i Norge

Under arbeid. Prosjekt under etablering.

#### Mål

Utvikle oppdatert dokumentasjon om bruk av [SMART App Launch](https://hl7.org/fhir/smart-app-launch/) i Norge med nødvendige tilpasninger.

#### Verktøy

* [GitHub Repository](https://github.com/HL7Norway/smart)
* [Chat på Zulip](https://chat.fhir.org/#narrow/channel/179226-norway/topic/SMART.20App.20Launch.20i.20Norge)
* [Prosjekt](https://github.com/orgs/HL7Norway/projects/13)

