# Home - Smart v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/ig/smart/ImplementationGuide/hl7.fhir.no.smart | *Version*:0.1.0 |
| Draft as of 2026-10-08 | *Computable Name*:smart |

### SMART on FHIR i Norge

Under arbeid. Prosjekt under etablering.

